# Test checklist (Android Chrome) - tick each, report failures with exact text/screenshot
A. Story input
- [ ] Pick horror + Hindi > "Load starter story template" > 3 scenes appear with Hindi captions
- [ ] Repeat for each language (Hindi, Haryanvi, Punjabi, English) and each category (6) - captions readable
- [ ] Type 3 lines in "write your own story" > "Use my story" > 3 scenes
- [ ] Toggle Hindi/English interface - labels change, nothing breaks
B. Scenes
- [ ] Add an image to scene 1 from your gallery; preview canvas shows it (cover-cropped)
- [ ] "Add many images" with 3 photos; scenes fill in order
- [ ] Edit a caption, change seconds, change transition, move scene up/down, delete a scene, + Scene
- [ ] Tap 15s / 30s / 45s / 60s; total shows e.g. "30s / 30s" (add scenes if it says add more)
C. Preview & voice
- [ ] Preview plays through all scenes with transitions
- [ ] Voice preview ON: the voice count for your language is shown; voice speaks; note its limits
D. Export & playback
- [ ] Export video 15s; progress bar moves; stays on tab with screen on
- [ ] Result video appears and PLAYS (picture + captions + music)
- [ ] Label says MP4 or WebM and matches the downloaded file extension
- [ ] Download works; file opens in the phone's gallery/Files player
- [ ] Press stop during export: you get "no file was created", no fake video
- [ ] Repeat once at 30s
E. PWA / offline (hosted on GitHub Pages only)
- [ ] Chrome offers Install; app opens in its own window with the icon
- [ ] Turn on airplane mode, reopen the app: interface loads; template + export still work
F. Optional AI (only if you set up a server)
- [ ] Paste https URL; status shows reachable; Gemini button creates scenes; wrong URL shows no crash
