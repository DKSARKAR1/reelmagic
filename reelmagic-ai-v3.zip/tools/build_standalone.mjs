// Builds site/: the flat set of static files for GitHub Pages (index.html + manifest + sw + icons).
// src/App.tsx is compiled here with the TypeScript compiler, so the phone loads plain JS (no in-browser Babel).
import fs from 'fs';import path from 'path';import {createRequire} from 'module';
const ts=createRequire(import.meta.url)('typescript');
const r=path.resolve(path.dirname(new URL(import.meta.url).pathname),'..');
const src=fs.readFileSync(r+'/src/App.tsx','utf8').replace(/import \{([^}]*)\} from 'react';/,'const {$1}=React;').replace('export default function App','function App');
const js=ts.transpileModule(src,{compilerOptions:{jsx:ts.JsxEmit.React,target:ts.ScriptTarget.ES2020,module:ts.ModuleKind.None}}).outputText;
const css=fs.readFileSync(r+'/src/index.css','utf8');
const html=`<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="theme-color" content="#8b5cf6"><link rel="manifest" href="manifest.webmanifest"><link rel="icon" href="icon-192.png"><title>ReelMagic AI</title><style>${css}</style></head><body><div id="root">Loading… (needs internet the first time)</div>
<script crossorigin="anonymous" src="https://cdn.jsdelivr.net/npm/react@18.3.1/umd/react.production.min.js"></script>
<script crossorigin="anonymous" src="https://cdn.jsdelivr.net/npm/react-dom@18.3.1/umd/react-dom.production.min.js"></script>
<script>${js}
ReactDOM.createRoot(document.getElementById('root')).render(React.createElement(App));
if('serviceWorker' in navigator&&location.protocol==='https:')navigator.serviceWorker.register('./sw.js').catch(function(){});</script></body></html>`;
fs.mkdirSync(r+'/site',{recursive:true});fs.writeFileSync(r+'/site/index.html',html);
for(const f of fs.readdirSync(r+'/public'))fs.copyFileSync(r+'/public/'+f,r+'/site/'+f);
console.log('site/ built:',fs.readdirSync(r+'/site').join(', '));
