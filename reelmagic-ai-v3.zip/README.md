# ReelMagic AI v3 (PWA-ready, no API key needed)
Story (template or your own) -> editable scenes (your images, captions, seconds, transitions) -> 9:16 canvas video -> real file recorded by the browser. Installable PWA when hosted on HTTPS.

## STATUS
Code compiles/parses (TypeScript transpile + `node --check` + manifest JSON check). It has NOT been run on a phone yet. Everything below is "untested" until you run TESTING.md and report back.

## Project structure (single source of truth)
- `src/App.tsx` - the whole app (React + TypeScript). Edit here only.
- `tools/build_standalone.mjs` - compiles App.tsx into `site/`.
- `site/` - the 5 flat files you publish: index.html, manifest.webmanifest, sw.js, icon-192.png, icon-512.png (generated; do not hand-edit).
- `public/` - manifest, service worker, icons (source copies; also used by Vite).
- `server/` - OPTIONAL Node server (Gemini stories, CORS, rate limit, motion-provider placeholder). Not needed for the app.
- Root `index.html` + `vite.config.ts` - only for `npm run dev` on a computer.

## Who does what (Claude vs Floot)
- Claude (this chat) edits the code and regenerates `site/` and the ZIP. Do code changes here.
- GitHub Pages hosts the static app for free. This is all you need now.
- Floot is a separate hosted app builder with its own project format. I have NOT verified that it imports this ZIP, and I did not change anything in your Floot account (it has only "Agency Sales Dashboard"). Do not give Floot the ZIP. If you later want a free-tier backend there for AI stories, the only relevant files are `server/index.ts`, `.env.example` (never upload your real key as a file; Floot has its own secret/env-var entry) - and the server would need to be adapted to Floot's backend format. Claude can do that through the connected Floot tools when you ask. Check Floot's current free-plan limits yourself.

## Publish free on GitHub Pages from Android Chrome
Placeholders: YOUR_GITHUB_USERNAME. Menus change; if one differs, tell me what you see.
1. Download the 5 files (index.html, manifest.webmanifest, sw.js, icon-192.png, icon-512.png) to your phone.
2. Chrome > github.com > sign up (free) > Chrome menu (3 dots) > "Desktop site" ON.
3. "+" > New repository > name `reelmagic` > Public > Create repository.
4. Click "uploading an existing file". Choose all 5 files at once (select multiple in the picker). Keep them at the repository root (no folders). Commit changes.
5. Settings > Pages > Source: "Deploy from a branch" > Branch `main`, folder `/ (root)` > Save.
6. Wait 1-3 minutes. Open https://YOUR_GITHUB_USERNAME.github.io/reelmagic/
7. Install: Chrome menu > "Install app" / "Add to Home screen" (or the in-app "Install app" button when Chrome offers it).
Updating: re-upload the changed files (same names). If the old version shows, close and reopen the app once.

## What works without any backend or payment
Templates, own stories, scene editing, preview, video export/download, music, voice preview, UI toggle, PWA install, offline UI after one online load.
## Needs a backend or an external service
- AI story writing: needs the `server/` running somewhere with GEMINI_API_KEY (free tier exists, check terms). Paste its https URL in "Optional AI features". Set ALLOWED_ORIGIN=https://YOUR_GITHUB_USERNAME.github.io on the server. GitHub Pages cannot hold secrets.
- AI moving scenes: NOT implemented. Needs an image-to-video provider (usually paid/credit-based) and a server adapter; only a placeholder route exists (returns 501).
- Voice inside the exported video: not possible with browser speech; needs a TTS API.
- Subscriptions/payments ($5/month, $50/year) and a one-free-video limit: not implemented.

## Voices
Browser speech uses voices installed on the phone (Android Text-to-speech engine). The app lists the voices it finds for the chosen language. Hindi usually exists; Punjabi may not; Haryanvi uses the Hindi voice. Speech is preview-only and is never recorded into the file.

## Offline
After one online load over HTTPS the service worker caches the page, icons and React, so the interface opens offline. Exporting works offline (it only uses the browser). AI server features need internet.

## Future Android APK
No APK exists. The PWA (manifest + service worker + icons, HTTPS) is the prerequisite for packaging, e.g. a Trusted Web Activity via Bubblewrap/PWABuilder (needs a computer or their online tool, Android signing, and a Play developer account only if you publish to Play). Not done or tested here.

## Optional commands (computer only)
`npm install`, `npm run dev`, `npm run build:standalone` (regenerates site/), `npm start` (server).

## Known limitations
- Real-time export: a 60 s video takes 60 s; keep the screen on and the tab open. Recording stops/breaks if you switch apps.
- MP4 only if the browser records MP4; otherwise WebM, labelled honestly.
- Templates have 3 scenes; for 45-60 s add scenes (max 20 s per scene).
- Fonts: Hindi/Punjabi captions depend on phone fonts.
- Haryanvi/Punjabi template wording should be checked by a native speaker.
- Large images use memory; use photos under ~15 MB.
- Verify licences of images/music/voices before commercial publishing; AI output is not guaranteed copyright-free.
