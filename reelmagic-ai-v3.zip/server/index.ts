import express from 'express';import path from 'path';
const app=express();app.use(express.json({limit:'20kb'}));
// Allow your GitHub Pages site (set ALLOWED_ORIGIN=https://YOUR_GITHUB_USERNAME.github.io) to call this server.
app.use((q,s,n)=>{const o=process.env.ALLOWED_ORIGIN;if(o&&q.headers.origin===o)s.set({'Access-Control-Allow-Origin':o,'Access-Control-Allow-Headers':'Content-Type','Access-Control-Allow-Methods':'GET,POST,OPTIONS'});if(q.method==='OPTIONS')return s.sendStatus(204);n()});
const hits=new Map<string,number[]>();const limited=(ip:string)=>{const n=Date.now(),a=(hits.get(ip)||[]).filter(x=>n-x<6e4);a.push(n);hits.set(ip,a);return a.length>10};
const SCRIPT:Record<string,string>={Hindi:'Devanagari',Haryanvi:'Devanagari (Haryanvi dialect)',Punjabi:'Gurmukhi',English:'Latin'};
app.get('/api/health',(_q,r)=>{r.json({gemini:!!process.env.GEMINI_API_KEY,motion:null})});
// AI moving scenes: provider adapter NOT implemented yet (needs a paid/credit-based image-to-video API).
app.post('/api/motion',(_q,r)=>{r.status(501).json({error:'No motion provider adapter is implemented yet.'})});
app.post('/api/story',async(req,res)=>{
  if(limited(req.ip||''))return res.status(429).json({error:'Too many requests. Try again in a minute.'});
  const key=process.env.GEMINI_API_KEY;
  if(!key)return res.status(503).json({error:'GEMINI_API_KEY is not configured on the server.'});
  const{idea,language,category,duration}=req.body??{};
  if(typeof idea!=='string'||!idea.trim()||idea.length>1000||!SCRIPT[language]||![15,30,45,60].includes(duration)||typeof category!=='string')
    return res.status(400).json({error:'Invalid input.'});
  const n=duration/5;
  const prompt=`Write an ORIGINAL ${category} short story for a ${duration}-second vertical reel, based on this idea: "${idea}".
Language: ${language}, written in ${SCRIPT[language]} script. Split into exactly ${n} scenes (~5 seconds each).
Return ONLY JSON: {"title":string,"scenes":[{"description":string(English),"narration":string(${language}, ~12 words),"subtitle":string(${language}, max 10 words),"visualPrompt":string(English, image-generation prompt)}]}`;
  try{
    const model=process.env.GEMINI_MODEL||'gemini-2.5-flash';
    const r=await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`,{method:'POST',
      headers:{'Content-Type':'application/json','x-goog-api-key':key},
      body:JSON.stringify({contents:[{parts:[{text:prompt}]}],generationConfig:{responseMimeType:'application/json',temperature:1}})});
    if(!r.ok)return res.status(502).json({error:`Gemini error ${r.status}`});
    const d:any=await r.json();
    const story=JSON.parse(d.candidates?.[0]?.content?.parts?.[0]?.text??'');
    if(!story.title||!Array.isArray(story.scenes)||!story.scenes.length)throw new Error('bad shape');
    res.json(story);
  }catch(e){res.status(502).json({error:'Story generation failed. Please try again.'})}
});
const dist=path.resolve('dist');app.use(express.static(dist));app.get('*',(_q,s)=>s.sendFile(path.join(dist,'index.html')));
app.listen(Number(process.env.PORT)||3001,()=>console.log('ReelMagic server up'));
