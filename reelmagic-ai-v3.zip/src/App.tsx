import {useEffect,useRef,useState} from 'react';
type Trans='fade'|'slide'|'zoom'|'none';
type Scene={id:number;caption:string;dur:number;trans:Trans;img?:string};
type Ctx={S:Scene[];imgs:Map<number,HTMLImageElement>;style:string;cat:string};
const LANGS=['Hindi','Haryanvi','Punjabi','English'] as const;type Lang=typeof LANGS[number];
const CATS=['horror','love','comedy','mythology','motivation','suspense'];
const CAT_HI=['हॉरर','प्रेम','कॉमेडी','पौराणिक','प्रेरणा','सस्पेंस'];
const ICON:Record<string,string>={horror:'👻',love:'💖',comedy:'😂',mythology:'🔱',motivation:'🔥',suspense:'🕵️'};
const PAL:Record<string,string[]>={Cinematic:['#2b1055','#f97316'],Cartoon:['#ec4899','#facc15'],Dark:['#0f0f1a','#7c3aed'],Dreamy:['#a78bfa','#fbcfe8']};
const VL:Record<string,string>={Hindi:'hi-IN',Haryanvi:'hi-IN',Punjabi:'pa-IN',English:'en-IN'};
const MIMES=['video/mp4;codecs=avc1.42E01E,mp4a.40.2','video/mp4','video/webm;codecs=vp9,opus','video/webm;codecs=vp8,opus','video/webm'];
// Original starter stories (3 scenes each, "|" separates scenes). Haryanvi/Punjabi text should be reviewed by a native speaker.
const TPL:Record<string,Record<Lang,string>>={
horror:{Hindi:'वो पुरानी हवेली सालों से खाली थी।|आज रात ऊपर की मोमबत्ती खुद जल उठी।|कानों में आवाज़ आई: "आख़िर तुम लौट आए।"',Haryanvi:'वो पुराणी हवेली बरसां तै खाली पड़ी थी।|आज रात ऊपर की मोमबत्ती आपै जल पड़ी।|कान म्हं आवाज आई: "आखिर तू आ गया।"',Punjabi:'ਉਹ ਪੁਰਾਣੀ ਹਵੇਲੀ ਸਾਲਾਂ ਤੋਂ ਖਾਲੀ ਸੀ।|ਅੱਜ ਰਾਤ ਉੱਪਰ ਮੋਮਬੱਤੀ ਆਪੇ ਬਲ ਪਈ।|ਕੰਨਾਂ ਵਿੱਚ ਆਵਾਜ਼ ਆਈ: "ਆਖ਼ਰ ਤੂੰ ਮੁੜ ਆਇਆ।"',English:'The old house had been empty for years.|Tonight, a candle lit itself upstairs.|A whisper said: "Finally, you came back."'},
love:{Hindi:'हर सुबह वो उसी बस स्टॉप पर इंतज़ार करती थी।|वो कुछ नहीं बोलता, बस अपनी छतरी बाँट देता।|सालों बाद भी वही छतरी दोनों को सँभाले है।',Haryanvi:'हर सुबह वो उसी बस अड्डे पै उडीक करै थी।|वो कुछ ना बोल्दा, बस आपणी छतरी बांट देता।|बरसां पाछै भी वा छतरी दोनूं नैं संभाले है।',Punjabi:'ਹਰ ਸਵੇਰ ਉਹ ਉਸੇ ਬੱਸ ਅੱਡੇ ਤੇ ਉਡੀਕ ਕਰਦੀ ਸੀ।|ਉਹ ਕੁਝ ਨਾ ਬੋਲਦਾ, ਬੱਸ ਆਪਣੀ ਛਤਰੀ ਸਾਂਝੀ ਕਰਦਾ।|ਸਾਲਾਂ ਬਾਅਦ ਵੀ ਉਹੀ ਛਤਰੀ ਦੋਵਾਂ ਨੂੰ ਸਾਂਭਦੀ ਹੈ।',English:'Every morning, she waited at the same bus stop.|He never spoke, only shared his umbrella.|Years later, that umbrella still covers them both.'},
comedy:{Hindi:'पापा ने कहा, पैसे बचाना सीखो।|मैंने घर के सारे चार्जर बचा लिए।|अब पूरा घर चार्जर ढूँढ रहा है।',Haryanvi:'बाप्पू नैं कही, पइसे बचाणा सीख।|मैं घर के सारे चार्जर बचा ल्याया।|अब सारा घर चार्जर टोह रह्या है।',Punjabi:'ਪਿਤਾ ਜੀ ਨੇ ਕਿਹਾ, ਪੈਸੇ ਬਚਾਉਣੇ ਸਿੱਖ।|ਮੈਂ ਘਰ ਦੇ ਸਾਰੇ ਚਾਰਜਰ ਬਚਾ ਲਏ।|ਹੁਣ ਸਾਰਾ ਘਰ ਚਾਰਜਰ ਲੱਭ ਰਿਹਾ ਹੈ।',English:'Dad told me to start saving money.|So I saved every charger in the house.|Now the whole family is hunting for a charger.'},
mythology:{Hindi:'एक युवा धनुर्धर बरगद के नीचे अभ्यास करता था।|उसे पक्षी नहीं, सिर्फ़ निशाने की आँख दिखती थी।|गुरु बोले, एकाग्रता ही सबसे बड़ा शस्त्र है।',Haryanvi:'एक छोरा धनुर्धर बड़ के हेठ्ठै अभ्यास करता।|उसनैं चिड़िया ना, बस निशाने की आंख दिखै थी।|गुरु बोल्ले, ध्यान ए सबतै बड़ा हथियार है।',Punjabi:'ਇੱਕ ਜਵਾਨ ਤੀਰਅੰਦਾਜ਼ ਬੋਹੜ ਹੇਠ ਅਭਿਆਸ ਕਰਦਾ ਸੀ।|ਉਸਨੂੰ ਪੰਛੀ ਨਹੀਂ, ਸਿਰਫ਼ ਨਿਸ਼ਾਨੇ ਦੀ ਅੱਖ ਦਿਸਦੀ ਸੀ।|ਗੁਰੂ ਬੋਲੇ, ਇਕਾਗਰਤਾ ਹੀ ਸਭ ਤੋਂ ਵੱਡਾ ਹਥਿਆਰ ਹੈ।',English:'A young archer practised under a banyan tree.|He ignored every bird and saw only the target.|Focus, said his teacher, is the greatest weapon.'},
motivation:{Hindi:'वो तीन बार परीक्षा में फेल हुआ।|सब हँसे, पर उसने पढ़ना नहीं छोड़ा।|चौथी बार उसने पूरे शहर में टॉप किया।',Haryanvi:'वो तीन बार इम्तिहान म्हं फेल होया।|सब हांसे, पर उसनैं पढ़णा ना छोड़्या।|चौथी बार उसनैं सारे शहर म्हं टॉप कर दिया।',Punjabi:'ਉਹ ਤਿੰਨ ਵਾਰ ਇਮਤਿਹਾਨ ਵਿੱਚ ਫੇਲ੍ਹ ਹੋਇਆ।|ਸਭ ਹੱਸੇ, ਪਰ ਉਸਨੇ ਪੜ੍ਹਨਾ ਨਹੀਂ ਛੱਡਿਆ।|ਚੌਥੀ ਵਾਰ ਉਸਨੇ ਪੂਰੇ ਸ਼ਹਿਰ ਵਿੱਚ ਟਾਪ ਕੀਤਾ।',English:'He failed his exam three times.|Everyone laughed, but he kept studying.|The fourth time, he topped the city.'},
suspense:{Hindi:'एक बिना भेजने वाले का ख़त आया।|अंदर बस मेरा पता था, मेरी ही लिखावट में।|पीछे का दरवाज़ा चरमराकर खुल गया।',Haryanvi:'एक चिट्ठी आई, भेजण आळे का नाम कोन्या।|भीतरै बस मेरा पता था, मेरी ए लिखाई म्हं।|पाछै का दरवाज्जा चरड़ कर खुल गया।',Punjabi:'ਇੱਕ ਬਿਨਾਂ ਭੇਜਣ ਵਾਲੇ ਦੀ ਚਿੱਠੀ ਆਈ।|ਅੰਦਰ ਬੱਸ ਮੇਰਾ ਪਤਾ ਸੀ, ਮੇਰੀ ਆਪਣੀ ਲਿਖਾਈ ਵਿੱਚ।|ਪਿੱਛੇ ਦਾ ਦਰਵਾਜ਼ਾ ਚੀਂ ਕਰਕੇ ਖੁੱਲ੍ਹ ਗਿਆ।',English:'A letter arrived with no sender.|Inside was only my address, in my own handwriting.|The door behind me creaked open.'}};
const W=720,H=1280,TD=.6;
function wrap(g:CanvasRenderingContext2D,text:string,w:number){const o:string[]=[];let l='';for(const x of text.split(' ')){const s=l?l+' '+x:x;if(g.measureText(s).width>w&&l){o.push(l);l=x}else l=s}o.push(l);return o}
function drawScene(g:CanvasRenderingContext2D,c:Ctx,i:number,lt:number,a:number,dx:number,z:number){
  const s=c.S[i],[c1,c2]=PAL[c.style],im=c.imgs.get(s.id);g.save();g.globalAlpha=a;g.translate(dx,0);
  g.save();g.translate(W/2,H/2);g.scale(z,z);g.translate(-W/2,-H/2);
  if(im&&s.img){const k=1+.06*Math.min(1,lt/s.dur),r=Math.max(W/im.naturalWidth,H/im.naturalHeight)*k;g.drawImage(im,(W-im.naturalWidth*r)/2,(H-im.naturalHeight*r)/2,im.naturalWidth*r,im.naturalHeight*r)}
  else{const gr=g.createLinearGradient(0,0,W*(i%2),H);gr.addColorStop(0,c1);gr.addColorStop(1,c2);g.fillStyle=gr;g.fillRect(0,0,W,H);g.textAlign='center';g.font='260px serif';g.fillText(ICON[c.cat]||'🎬',W/2,560)}
  g.restore();
  if(s.caption){g.textAlign='center';g.font='bold 46px "Noto Sans Devanagari","Noto Sans Gurmukhi",sans-serif';const ls=wrap(g,s.caption,610),h=ls.length*60+40;
    g.fillStyle='rgba(0,0,0,.6)';g.fillRect(40,1020-h/2,640,h);g.fillStyle='#fff';ls.forEach((l,k)=>g.fillText(l,W/2,1020-h/2+55+k*60))}
  g.restore();
}
function drawFrame(g:CanvasRenderingContext2D,c:Ctx,t:number):number{
  const S=c.S,total=S.reduce((a,s)=>a+s.dur,0);let i=0,s0=0,st=0;
  for(let k=0;k<S.length;k++){if(t>=st){i=k;s0=st}st+=S[k].dur}
  const lt=t-s0,s=S[i];g.fillStyle='#000';g.fillRect(0,0,W,H);
  if(i>0&&s.trans!=='none'&&lt<TD){const p=lt/TD,pl=S[i-1].dur+lt;
    if(s.trans==='slide'){drawScene(g,c,i-1,pl,1,-p*W,1);drawScene(g,c,i,lt,1,(1-p)*W,1)}
    else{drawScene(g,c,i-1,pl,1,0,1);drawScene(g,c,i,lt,p,0,s.trans==='zoom'?1.25-.25*p:1)}
  }else drawScene(g,c,i,lt,1,0,1);
  g.fillStyle='rgba(255,255,255,.85)';g.fillRect(0,H-10,W*Math.min(1,t/total),10);return i;
}
const playable=(u:string)=>new Promise<boolean>(r=>{const v=document.createElement('video');v.preload='metadata';v.onloadedmetadata=()=>r(true);v.onerror=()=>r(false);setTimeout(()=>r(false),8000);v.src=u});
const sup=(m:string)=>typeof MediaRecorder!=='undefined'&&MediaRecorder.isTypeSupported(m);

export default function App(){
  const [ui,setUi]=useState<'en'|'hi'>('en');const t=(e:string,h:string)=>ui==='en'?e:h;
  const [lang,setLang]=useState<Lang>('Hindi'),[cat,setCat]=useState('motivation'),[style,setStyle]=useState('Cinematic'),[own,setOwn]=useState('');
  const [scenes,setScenes]=useState<Scene[]>([]),[voice,setVoice]=useState(false),[music,setMusic]=useState(true);
  const [busy,setBusy]=useState<''|'prev'|'rec'|'ai'>(''),[pct,setPct]=useState(0),[err,setErr]=useState(''),[url,setUrl]=useState(''),[fmt,setFmt]=useState(''),[ai,setAi]=useState(false),[tick,setTick]=useState(0);
  const [len,setLen]=useState(15),[base,setBase]=useState(()=>{try{return localStorage.getItem('rm_ai')||''}catch{return ''}}),[caps,setCaps]=useState<{gemini?:boolean;motion?:string|null}>({}),[voices,setVoices]=useState<SpeechSynthesisVoice[]>([]),[vn,setVn]=useState(''),[inst,setInst]=useState<any>(null);
  const imgs=useRef(new Map<number,HTMLImageElement>()),cv=useRef<HTMLCanvasElement>(null),scR=useRef(scenes),stopR=useRef(false),idR=useRef(1);scR.current=scenes;
  const mp4=sup('video/mp4'),webm=sup('video/webm');
  useEffect(()=>{setAi(false);setCaps({});fetch(base.replace(/\/+$/,'')+'/api/health').then(r=>r.json()).then(d=>{setAi(!!d.gemini);setCaps(d)}).catch(()=>{})},[base]);
  useEffect(()=>{if(!('speechSynthesis' in window))return;const f=()=>setVoices(speechSynthesis.getVoices());f();speechSynthesis.addEventListener('voiceschanged',f);return()=>speechSynthesis.removeEventListener('voiceschanged',f)},[]);
  useEffect(()=>{const h=(e:Event)=>{e.preventDefault();setInst(e)};window.addEventListener('beforeinstallprompt',h);return()=>window.removeEventListener('beforeinstallprompt',h)},[]);
  useEffect(()=>{const g=cv.current?.getContext('2d');if(g&&scenes.length&&!busy||g&&scenes.length&&busy==='ai')drawFrame(g!,{S:scenes,imgs:imgs.current,style,cat},0)},[scenes,style,cat,busy,tick]);
  const upd=(id:number,p:Partial<Scene>)=>setScenes(S=>S.map(s=>s.id===id?{...s,...p}:s));
  const nid=()=>idR.current++;
  function fromLines(lines:string[],total=scR.current.reduce((a,s)=>a+s.dur,0)||15){
    const d=Math.min(20,Math.max(1,Math.round(total/lines.length*10)/10)),old=scR.current;
    setScenes(lines.map((c,i)=>({id:old[i]?.id??nid(),caption:c,dur:d,trans:old[i]?.trans??'fade',img:old[i]?.img})));
  }
  const tpl=()=>fromLines(TPL[cat][lang].split('|'),len);
  function useOwn(){const x=own.trim();if(!x)return setErr(t('Write your story first.','पहले अपनी कहानी लिखें।'));
    let L=x.split(/\n+/).map(s=>s.trim()).filter(Boolean);if(L.length<2)L=x.split(/(?<=[.!?।])\s+/).filter(Boolean);setErr('');fromLines(L.slice(0,12).map(s=>s.slice(0,200)),len)}
  const fit=(n:number)=>{setLen(n);setScenes(S=>S.map(s=>({...s,dur:Math.min(20,Math.max(1,Math.round(n/S.length*10)/10))})))};
  async function loadImg(id:number,f:File){if(!f.type.startsWith('image/')||f.size>15e6)throw new Error(t('Choose an image under 15 MB.','15 MB से छोटी इमेज चुनें।'));
    const u=URL.createObjectURL(f),im=new Image();im.src=u;try{await im.decode()}catch{throw new Error(t('Could not read that image.','इमेज पढ़ी नहीं जा सकी।'))}imgs.current.set(id,im);return u}
  async function setImg(id:number,f?:File){if(!f)return;try{upd(id,{img:await loadImg(id,f)});setErr('')}catch(e){setErr((e as Error).message)}}
  async function bulk(fs:FileList|null){if(!fs)return;const S=scR.current.map(s=>({...s}));
    try{for(const f of Array.from(fs)){let s=S.find(x=>!x.img);if(!s){s={id:nid(),caption:'',dur:3,trans:'fade'};S.push(s)}s.img=await loadImg(s.id,f)}setScenes(S);setErr('')}catch(e){setErr((e as Error).message);setScenes(S)}}
  const move=(i:number,d:number)=>setScenes(S=>{const a=[...S],j=i+d;if(j<0||j>=a.length)return a;[a[i],a[j]]=[a[j],a[i]];return a});
  async function gemini(){setErr('');setBusy('ai');try{const total=scR.current.reduce((a,s)=>a+s.dur,0),dur=[15,30,45,60].reduce((p,c)=>Math.abs(c-total)<Math.abs(p-total)?c:p,15);
    const r=await fetch(base.replace(/\/+$/,'')+'/api/story',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({idea:own||'A short surprising story',language:lang,category:cat,duration:dur})});
    const d=await r.json().catch(()=>({}));if(!r.ok)throw new Error(d.error||'Gemini request failed');setLen(dur);fromLines(d.scenes.map((s:{subtitle:string})=>s.subtitle),dur)}catch(e){setErr((e as Error).message)}finally{setBusy('')}}
  async function play(record:boolean){
    if(busy)return;const S=scR.current;if(!S.length)return setErr(t('Add at least one scene.','कम से कम एक सीन जोड़ें।'));
    setErr('');setUrl('');setFmt('');stopR.current=false;
    const c:Ctx={S,imgs:imgs.current,style,cat},g=cv.current!.getContext('2d')!,total=S.reduce((a,s)=>a+s.dur,0);
    let ac:AudioContext|undefined,oscs:OscillatorNode[]=[],rec:MediaRecorder|undefined;const chunks:Blob[]=[];
    try{
      let mime:string|undefined;
      if(record){if(typeof MediaRecorder==='undefined'||!cv.current!.captureStream)throw new Error(t('This browser cannot record video. Use the latest Chrome.','यह ब्राउज़र वीडियो रिकॉर्ड नहीं कर सकता। नया Chrome इस्तेमाल करें।'));
        mime=MIMES.find(sup);if(!mime)throw new Error(t('No supported video recording format found.','कोई सपोर्टेड वीडियो फ़ॉर्मेट नहीं मिला।'))}
      setBusy(record?'rec':'prev');
      let dest:MediaStreamAudioDestinationNode|undefined;
      if(music){ac=new AudioContext();const gn=ac.createGain();gn.gain.value=.06;if(record){dest=ac.createMediaStreamDestination();gn.connect(dest)}else gn.connect(ac.destination);
        oscs=[220,277.2,329.6].map(f=>{const o=ac!.createOscillator();o.type='triangle';o.frequency.value=f;o.connect(gn);o.start();return o})}
      if(record){const stream=cv.current!.captureStream(30);dest?.stream.getAudioTracks().forEach(k=>stream.addTrack(k));
        rec=new MediaRecorder(stream,{mimeType:mime,videoBitsPerSecond:4e6});rec.ondataavailable=e=>{if(e.data.size)chunks.push(e.data)}}
      const stopped=rec?new Promise<void>(r=>{rec!.onstop=()=>r()}):Promise.resolve();rec?.start(500);
      const t0=performance.now();let last=-1;
      await new Promise<void>(res=>{const f=()=>{const tt=(performance.now()-t0)/1000;if(tt>=total||stopR.current)return res();const i=drawFrame(g,c,tt);
        if(i!==last){last=i;oscs.forEach((o,k)=>o.frequency.setTargetAtTime([220,277.2,329.6][k]*[1,1.125,1.2,1.333][i%4],ac!.currentTime,.5));
          if(voice&&'speechSynthesis' in window&&S[i].caption){speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(S[i].caption);u.lang=VL[lang];const vo=voices.find(v=>v.name===vn);if(vo)u.voice=vo;speechSynthesis.speak(u)}}
        setPct(tt/total);requestAnimationFrame(f)};f()});
      if(rec){rec.stop();await stopped;if(stopR.current)throw new Error(t('Export stopped. No file was created.','एक्सपोर्ट रोका गया। कोई फ़ाइल नहीं बनी।'));
        const type=(rec.mimeType||mime||'').split(';')[0],blob=new Blob(chunks,{type});if(!blob.size)throw new Error(t('Recording was empty.','रिकॉर्डिंग खाली थी।'));
        const u=URL.createObjectURL(blob);if(!(await playable(u)))throw new Error(t('The recorded file could not be played back, so it was discarded.','रिकॉर्ड की गई फ़ाइल प्ले नहीं हुई, इसलिए हटा दी गई।'));
        setFmt(type.includes('mp4')?'mp4':'webm');setUrl(u)}
    }catch(e){setErr((e as Error).message)}finally{oscs.forEach(o=>o.stop());ac?.close();if('speechSynthesis' in window)speechSynthesis.cancel();setBusy('');setPct(0);setTick(x=>x+1)}
  }
  const lv=voices.filter(v=>v.lang.toLowerCase().replace('_','-').startsWith(VL[lang].slice(0,2)));\n  const total=Math.round(scenes.reduce((a,s)=>a+s.dur,0)*10)/10;
  return <div className="w">
    <div className="f" style={{display:'flex',justifyContent:'space-between',alignItems:'center'}}><div><h1>🎬 ReelMagic AI</h1><div className="n">{t('Make vertical Reels from your story & photos — no API key needed','अपनी कहानी और फोटो से वर्टिकल रील बनाएँ — API key ज़रूरी नहीं')}</div></div>
      <button className="b" onClick={()=>setUi(ui==='en'?'hi':'en')}>{ui==='en'?'हिंदी':'EN'}</button></div>
    <div className="c"><h3>1. {t('Story','कहानी')}</h3>
      <div className="row"><select value={cat} onChange={e=>setCat(e.target.value)}>{CATS.map((k,i)=><option key={k} value={k}>{ICON[k]} {ui==='en'?k:CAT_HI[i]}</option>)}</select>
        <select value={lang} onChange={e=>setLang(e.target.value as Lang)}>{LANGS.map(x=><option key={x}>{x}</option>)}</select></div>
      <button className="b" onClick={tpl}>{t('Load starter story template','रेडीमेड कहानी लोड करें')}</button>
      <textarea value={own} onChange={e=>setOwn(e.target.value)} placeholder={t('…or write your own story (one line = one scene)','…या अपनी कहानी लिखें (एक लाइन = एक सीन)')}/>
      <button className="b" onClick={useOwn}>{t('Use my story','मेरी कहानी इस्तेमाल करें')}</button>
      {ai&&<button className="b" disabled={!!busy} onClick={gemini}>✨ {t('Optional: write with Gemini (server key found)','वैकल्पिक: Gemini से लिखें')}</button>}
      <div className="n">{t('Video length','वीडियो की लंबाई')}: {total}s / {len}s{total<len-1?' — '+t('add more scenes to reach the target (max 20s per scene)','लक्ष्य के लिए और सीन जोड़ें (प्रति सीन अधिकतम 20s)'):''}</div><div className="row">{[15,30,45,60].map(n=><button key={n} className={len===n?'b':'sm'} onClick={()=>fit(n)}>{n}s</button>)}</div>
    </div>
    <div className="c"><h3>2. {t('Scenes','सीन')} ({scenes.length})</h3>
      {!scenes.length&&<div className="n">{t('Load a template or use your story to create scenes.','सीन बनाने के लिए टेम्पलेट लोड करें या अपनी कहानी इस्तेमाल करें।')}</div>}
      {scenes.map((s,i)=><div className="sc" key={s.id}>
        <div className="row">{s.img?<img className="th" src={s.img} alt=""/>:<div className="th">{ICON[cat]}</div>}
          <label className="b sm">📷 {s.img?t('Replace','बदलें'):t('Add image','इमेज')}<input hidden type="file" accept="image/*" onChange={e=>{setImg(s.id,e.target.files?.[0]);e.target.value=''}}/></label>
          <button className="sm" onClick={()=>move(i,-1)}>↑</button><button className="sm" onClick={()=>move(i,1)}>↓</button>
          <button className="sm" onClick={()=>{imgs.current.delete(s.id);setScenes(S=>S.filter(x=>x.id!==s.id))}}>✕</button></div>
        <textarea value={s.caption} onChange={e=>upd(s.id,{caption:e.target.value})} placeholder={t('Caption','कैप्शन')}/>
        <div className="row"><label className="n">{t('Seconds','सेकंड')}<input type="number" min={1} max={20} step={.5} value={s.dur} onChange={e=>upd(s.id,{dur:Math.max(1,Math.min(20,+e.target.value||1))})}/></label>
          <label className="n">{t('Transition in','ट्रांज़िशन')}<select value={s.trans} onChange={e=>upd(s.id,{trans:e.target.value as Trans})}>{['fade','slide','zoom','none'].map(x=><option key={x}>{x}</option>)}</select></label></div>
      </div>)}
      <div className="row"><button className="b" onClick={()=>setScenes(S=>[...S,{id:nid(),caption:'',dur:3,trans:'fade'}])}>+ {t('Scene','सीन')}</button>
        <label className="b">📷 {t('Add many images','कई इमेज')}<input hidden type="file" accept="image/*" multiple onChange={e=>{bulk(e.target.files);e.target.value=''}}/></label></div>
      <div className="n">{t('Use your own photos, or free-licence sites such as Pexels, Pixabay or Unsplash — read each licence before commercial use. Without an image a scene uses a built-in gradient + emoji.','अपनी फोटो या Pexels/Pixabay/Unsplash जैसी फ्री-लाइसेंस साइट की इमेज इस्तेमाल करें — व्यावसायिक उपयोग से पहले लाइसेंस पढ़ें। इमेज न हो तो ग्रेडिएंट + इमोजी लगता है।')}</div>
    </div>
    <div className="c"><h3>3. {t('Preview & export','प्रीव्यू और एक्सपोर्ट')}</h3>
      <canvas ref={cv} width={W} height={H} style={{width:'100%',maxWidth:320,margin:'auto',aspectRatio:'9/16',borderRadius:14,background:'#000'}}/>
      <label>{t('Style (for scenes without images)','स्टाइल (बिना इमेज वाले सीन)')}<select value={style} onChange={e=>setStyle(e.target.value)}>{Object.keys(PAL).map(x=><option key={x}>{x}</option>)}</select></label>
      <label className="n"><input type="checkbox" checked={music} onChange={e=>setMusic(e.target.checked)}/> {t('Background music (original, synthesized — included in export)','बैकग्राउंड म्यूज़िक (ओरिजिनल, एक्सपोर्ट में शामिल)')}</label>
      <label className="n"><input type="checkbox" checked={voice} onChange={e=>setVoice(e.target.checked)}/> {t('Voice preview (browser speech, language above)','वॉइस प्रीव्यू (ब्राउज़र स्पीच)')}</label>
      <div className="n">⚠️ {t('Browser speech plays through the speaker only. It CANNOT be recorded into the exported video — the file contains captions + music only. Hindi/Punjabi voices depend on your phone.','ब्राउज़र की आवाज़ सिर्फ़ स्पीकर से बजती है, एक्सपोर्ट वीडियो में रिकॉर्ड नहीं हो सकती — फ़ाइल में कैप्शन + म्यूज़िक ही होंगे।')}</div>
      <div className="n">🔊 {t('Voices on this phone for','इस फोन पर आवाज़ें')} {lang}: {'speechSynthesis' in window?(lv.length||t('none installed — add one in Android Text-to-speech settings','कोई नहीं — Android Text-to-speech सेटिंग में जोड़ें')):t('speech not supported','स्पीच सपोर्टेड नहीं')}</div>
      {lv.length>0&&<select value={vn} onChange={e=>setVn(e.target.value)}><option value="">{t('Default voice','डिफ़ॉल्ट आवाज़')}</option>{lv.map(v=><option key={v.name} value={v.name}>{v.name}</option>)}</select>}
      <div className="row"><button className="b" disabled={!!busy} onClick={()=>play(false)}>▶ {t('Preview','प्रीव्यू')}</button><button className="b" disabled={!!busy} onClick={()=>play(true)}>⏺ {t('Export video','वीडियो एक्सपोर्ट')}</button>{(busy==='prev'||busy==='rec')&&<button className="b" onClick={()=>{stopR.current=true}}>■</button>}</div>
      {(busy==='prev'||busy==='rec')&&<><div>{busy==='rec'?t('Recording in real time — keep this tab open and screen on…','रिकॉर्डिंग चल रही है — टैब खुला और स्क्रीन ऑन रखें…'):t('Previewing…','प्रीव्यू…')}</div><div className="bar"><i style={{width:Math.round(pct*100)+'%'}}/></div></>}
      {err&&<div className="e">{err}</div>}
      <div className="n">{t('This browser can record:','यह ब्राउज़र रिकॉर्ड कर सकता है:')} MP4 {mp4?'✔':'✘'} · WebM {webm?'✔':'✘'}</div>
      {url&&<><video src={url} controls playsInline style={{width:'100%',maxHeight:'60vh',borderRadius:14,background:'#000'}}/>
        <a className="b" href={url} download={`reelmagic.${fmt}`}>⬇ {t('Download','डाउनलोड')} .{fmt.toUpperCase()}</a>
        <div className="n">{fmt==='mp4'?t('Real MP4 recorded by your browser.','आपके ब्राउज़र द्वारा रिकॉर्ड किया गया असली MP4।'):t('Your browser records WebM only — saved as .webm (NOT MP4). It plays in Chrome/VLC; convert to MP4 with a free converter if needed.','आपका ब्राउज़र सिर्फ़ WebM रिकॉर्ड करता है — .webm के रूप में सेव (MP4 नहीं)।')}</div></>}
      <div className="n">⚠️ {t('Verify licensing of images, music and voices before commercial publishing.','व्यावसायिक प्रकाशन से पहले इमेज, संगीत और आवाज़ का लाइसेंस जाँचें।')}</div>
    </div>
    <div className="c"><h3>{t('Optional AI features','वैकल्पिक AI फीचर')}</h3>
      {inst&&<button className="b" onClick={async()=>{inst.prompt();await inst.userChoice;setInst(null)}}>📲 {t('Install app on this phone','इस फोन पर ऐप इंस्टॉल करें')}</button>}
      <input type="url" placeholder="https://your-ai-server.example (optional, https only)" defaultValue={base} onBlur={e=>{const v=e.target.value.trim();if(v&&!/^https:\/\//.test(v))return setErr(t('AI server URL must start with https://','AI सर्वर URL https:// से शुरू होना चाहिए'));try{localStorage.setItem('rm_ai',v)}catch{}setBase(v)}}/>
      <div className="n">{ai?'✅ '+t('AI server reachable — Gemini story button enabled','AI सर्वर जुड़ा — Gemini बटन चालू'):'⚪ '+t('No AI server connected (the app works fully without one).','कोई AI सर्वर नहीं (ऐप उसके बिना भी पूरा चलता है)।')} · {t('Motion provider','मोशन प्रोवाइडर')}: {caps.motion||t('none (not implemented yet)','कोई नहीं (अभी लागू नहीं)')}</div>
      <div className="n">✨ {t('AI story writing: needs a Gemini API key on the server (free tier exists). Not needed for the app.','AI कहानी: सर्वर पर Gemini API key चाहिए (फ्री टियर उपलब्ध)। ऐप के लिए ज़रूरी नहीं।')}<br/>🎞 {t('AI moving scenes / AI images: NOT included. They need an external image/video generation API (usually paid or credit-based). Nothing here pretends to do this.','AI मूविंग सीन / AI इमेज: शामिल नहीं। इसके लिए बाहरी इमेज/वीडियो API चाहिए (आमतौर पर पेड)।')}<br/>💳 {t('Plans ($5/month, $50/year) are a future version — no payments exist.','प्लान ($5/माह, $50/साल) भविष्य के वर्ज़न में — अभी कोई पेमेंट नहीं।')}</div></div>
  </div>;
}
